source("lgd.R")
#### Simulation Part ####
generate.x <- function(n, p) {
    return(matrix(runif(n*p), nrow=n))
}

generate.y.v1 <- function(x) {
    tmpResult <- (3 * x[, 2] - 5*x[, 3]) * (x[, 4] + x[, 5] <= 1) + 
        (-5 * x[, 1] + 10 * x[, 2]) * (x[, 4] + x[, 5] >1)
    tmpResult <- as.numeric(runif(nrow(x)) < sigmoid(tmpResult))
    return(tmpResult)
}


model <- list()
model$n <- 1000
model$p <- 3
model$q <- 2
model$diff <- lg.diff
model$init <- lg.init.beta
model$pred <- lg.pred
model$loss <- lg.loss
model$lambda <- 0.05
model$ntree <- 400
model$subsample <- 1
model$quantile_cut <- 0.02
model$control <- rpart.control(maxdepth = 3, minsplit = 10, cp=0)
model$woods <- list()

x <- generate.x(n=model$n, p=model$p + model$q)
y <- generate.y.v1(x)
res <- lgd(y=y, x=x[, 1:3], z=x[, 4:5], model=model)


cat("(max, min): ", max(res$beta[, 1]), min(res$beta[, 1]), "\n")
png(filename="sim_lr_1.png", width=240, height=200)
Value = res$beta[, 1]
qplot(x=x[, 4], y=x[, 5], geom="point", 
      color = Value,
      main = expression(paste(beta[1], " ~ ", z[1], ",", z[2])),
      xlab = expression(z[1]),
      ylab = expression(z[2])) + 
    scale_color_distiller(palette="RdBu", direction=1)
dev.off()
cat("(max, min): ", max(res$beta[, 2]), min(res$beta[, 2]), "\n")
png(filename="sim_lr_2.png", width=240, height=200)
Value = res$beta[, 2]
qplot(x=x[, 4], y=x[, 5], geom="point", 
      color = Value,
      main = expression(paste(beta[2], " ~ ", z[1], ",", z[2])),
      xlab = expression(z[1]),
      ylab = expression(z[2])) + 
    scale_color_distiller(palette="RdBu", direction=1)
dev.off()
cat("(max, min): ", max(res$beta[, 3]), min(res$beta[, 3]), "\n")
png(filename="sim_lr_3.png", width=240, height=200)
Value = res$beta[, 3]
qplot(x=x[, 4], y=x[, 5], geom="point", 
      color = Value,
      main = expression(paste(beta[3], " ~ ", z[1], ",", z[2])),
      xlab = expression(z[1]),
      ylab = expression(z[2])) + 
    scale_color_distiller(palette="RdBu", direction=1)
dev.off()

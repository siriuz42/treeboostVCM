library(rpart)
library(gbm)
source("lgd.R")
source("BoostTree.R")

decompress <- function(data, 
                       actionCntSet, actionFctSet, predictSet,
                       testFlag) {
    res <- list()
    res$train <- subset(data, !testFlag)
    res$test <- subset(data, testFlag)
    res$xTrain <- c()
    res$yTrain <- c()
    res$zTrain <- c()
    res$xTest <- c()
    res$yTest <- c()
    res$zTest <- c()
    
    for (col in actionCntSet) {
        res$zTrain <- cbind(res$zTrain, as.numeric(as.vector(data[[col]]))[!testFlag])
        res$zTest <- cbind(res$zTest, as.numeric(as.vector(data[[col]]))[testFlag])
    }
    for (col in actionFctSet) {
        res$zTrain <- cbind(res$zTrain, as.numeric(as.factor(as.vector(data[[col]])))[!testFlag])
        res$zTest <- cbind(res$zTest, as.numeric(as.factor(as.vector(data[[col]])))[testFlag])
    }
    for (col in predictSet) {
        res$xTrain <- cbind(res$xTrain, as.numeric(as.vector(data[[col]]))[!testFlag])
        res$xTest <- cbind(res$xTest, as.numeric(as.vector(data[[col]]))[testFlag])
    }
    res$yTrain <-  as.numeric(as.vector(data[[target]]))[!testFlag]
    res$yTest <-  as.numeric(as.vector(data[[target]]))[testFlag]
    return(res)
}

c.formula <- function(target, predictSet, actionCntSet = c(), actionFctSet = c()) {
    strPredictSet <- paste(predictSet, collapse="+")
    strActionCntSet <- paste(actionCntSet, collapse="+")
    if (strActionCntSet != "") {
        strActionCntSet <- paste(strActionCntSet, "+", sep="")
    }
    strActionFctSet = ""
    if (!is.null(actionFctSet)) {
        strActionFctSet <- paste(paste("factor(", actionFctSet, ")", sep=""), collapse="+")
        strActionFctSet <- paste(strActionFctSet, "+", sep="")
    } 
    return(as.formula(paste(target, "~", strActionCntSet, strActionFctSet, strPredictSet, sep="")))
}

l2 <- function(a, b) {return(mean((a-b)^2))}

#### DATASET: BEIJINGPM ####
set.seed(42)
id <- "beijingpm"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- subset(data, !is.na(pm2.5))
n <- dim(data)[1]

tenFold <- sample(1:10, size=n, replace=TRUE)
result <- c()
actionCntSet <- c()
actionFctSet <- c("cbwd", "year", "month", "day", "hour")
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("DEWP", "TEMP", "PRES", "Iws", "Is", "Ir")
target <- "pm2.5"
gSubsample <- 0.5

modelS <- list()
modelS$diff <- ols.diff
modelS$init <- ols.init.beta
modelS$pred <- ols.pred
modelS$loss <- ols.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.05
modelS$method <- "ordinary"
modelS$subsample <- gSubsample

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 6, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 0.1
modelB$control <- rpart.control(maxdepth = 6, minsplits=100, cp=0.001)
modelB$method <- "boulevard"
modelB$inflate <- 1

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- lm(c.formula(target, predictSet),
                data = simData$train)
    tmp <- c(tmp,
             rLmFit = l2(predict(lmFit, newdata = simData$test), simData$yTest))
    
    lmFitSat <- lm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                   data = simData$train)
    tmp <- c(tmp,
             rLmFitSat = l2(predict(lmFitSat, newdata = simData$test), simData$yTest))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train,
                  distribution = "gaussian",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp <- c(tmp,
             rGbmFit = l2(predict(gbmFit, newdata = simData$test, modelS$ntree), simData$yTest))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp <- c(tmp,
             rSvcmFit = l2(lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit),
                           simData$yTest))

    gc()
    modelB$n = sum(!testFlag)
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp, rBvcmFitL = l2(tmpPred, simData$yTest),
             rBvcmFitR = l2(tmpPred * bvcmFit$inflate,  simData$yTest))
  
    gc()
    cat("ALERT!")
    pvcmFit <- Boost.Tree(simData$zTrain,cbind(1, simData$xTrain), simData$yTrain,
                       actionSet, nBoost=modelS$ntree, nu=modelS$lambda,
                       mini.size=modelS$control$minsplit, M=16, fit.method="linear")
    tmpPred <- pred.Boost(simData$zTest, cbind(1, simData$xTest), simData$yTest, pvcmFit,
                          nBoost=modelS$ntree, nu=modelS$lambda)
    
    tmp <- c(tmp, rPcvmFitL=tmpPred$L2.error)
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

# save(result, file=paste("Accuracy/", id, ".RData", sep=""))
save(result, file=paste("Accuracy/", id, "2.RData", sep=""))


#### DATASET: BIKEHOUR ####
set.seed(42)
id <- "bikehour"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- subset(data, !is.na(cnt))
n <- dim(data)[1]

tenFold <- sample(1:10, size=n, replace=TRUE)
result <- c()
actionCntSet <- c()
actionFctSet <- c("weathersit", "season", "weekday", "mnth", "hr")
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("temp", "atemp", "hum", "windspeed")
target <- "cnt"
gSubsample <- 0.5

modelS <- list()
modelS$diff <- ols.diff
modelS$init <- ols.init.beta
modelS$pred <- ols.pred
modelS$loss <- ols.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.05
modelS$method <- "ordinary"
modelS$subsample <- gSubsample

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 5, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 0.1
modelB$control <- rpart.control(maxdepth = 5, minsplits=100, cp=0.001)
modelB$method <- "boulevard"
modelB$inflate <- 1

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- lm(c.formula(target, predictSet),
                data = simData$train)
    tmp <- c(tmp, 
             rLmFit = l2(predict(lmFit, newdata = simData$test), simData$yTest))
    
    lmFitSat <- lm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                   data = simData$train)
    tmp <- c(tmp, 
             rLmFitSat = l2(predict(lmFitSat, newdata = simData$test), simData$yTest))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "gaussian",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp <- c(tmp, 
             rGbmFit = l2(predict(gbmFit, newdata = simData$test, modelS$ntree), simData$yTest))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp <- c(tmp,
             rSvcmFit = l2(lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit),
                           simData$yTest))

    gc()
    modelB$n = sum(!testFlag) 
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp, rBvcmFitL = l2(tmpPred, simData$yTest),
             rBvcmFitR = l2(tmpPred * bvcmFit$inflate,  simData$yTest))
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))


#### DATASET: STARCRAFT ####
set.seed(42)
id <- "starcraft"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- data[complete.cases(data), ]

result <- c()
actionCntSet <- c("Age", "HoursPerWeek", "UniqueHotkeys", "ComplexUnitsMade")
actionFctSet <- c()
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("SelectByHotkeys", "AssignToHotkeys", "MinimapAttacks", "MinimapRightClicks", 
                "GapBetweenPACs", "TotalMapExplored", "WorkersMade", "ComplexAbilitiesUsed")
target <- "LeagueIndex"
for (key in union(actionCntSet, predictSet)) {
    if (is.factor(data[[key]])) {
        data[[key]] = as.numeric(levels(data[[key]]))[data[[key]]]
    }
}
data <- data[complete.cases(data), ]
n <- dim(data)[1]
tenFold <- sample(1:10, size=n, replace=TRUE)

gSubsample <- 0.8

modelS <- list()
modelS$diff <- ols.diff
modelS$init <- ols.init.beta
modelS$pred <- ols.pred
modelS$loss <- ols.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.05
modelS$method <- "ordinary"
modelS$subsample <- gSubsample

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 4, minsplits=10, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 4, minsplits=10, cp=0.001)
modelB$method <- "boulevard"
modelB$inflate <- 1

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- lm(c.formula(target, predictSet),
                data = simData$train)
    tmp <- c(tmp, 
             rLmFit = l2(predict(lmFit, newdata = simData$test), simData$yTest))
    
    lmFitSat <- lm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                   data = simData$train)
    tmp <- c(tmp, 
             rLmFitSat = l2(predict(lmFitSat, newdata = simData$test), simData$yTest))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "gaussian",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp <- c(tmp, 
             rGbmFit = l2(predict(gbmFit, newdata = simData$test, modelS$ntree), simData$yTest))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp <- c(tmp,
             rSvcmFit = l2(lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit),
                           simData$yTest))

    gc()
    modelB$n = sum(!testFlag) 
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp, rBvcmFitL = l2(tmpPred, simData$yTest),
             rBvcmFitR = l2(tmpPred * bvcmFit$inflate,  simData$yTest))
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))
#### DATASET: ONLINENEWS ####
set.seed(42)
id <- "onlinenews"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- data[complete.cases(data), ]

result <- c()
actionCntSet <- c("n_tokens_title", "n_tokens_content", "num_imgs")
actionFctSet <- c("is_weekend")
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("self_reference_avg_sharess", 
                "global_subjectivity", "global_sentiment_polarity", 
                "global_rate_positive_words", "global_rate_negative_words")
target <- "shares"
for (key in union(actionCntSet, predictSet)) {
    if (is.factor(data[[key]])) {
        data[[key]] <- as.numeric(levels(data[[key]]))[data[[key]]]
    }
}
data <- data[complete.cases(data), ]
data[[target]] <- log(data[[target]])
n <- dim(data)[1]
tenFold <- sample(1:10, size=n, replace=TRUE)

gSubsample <- 0.5

modelS <- list()
modelS$diff <- ols.diff
modelS$init <- ols.init.beta
modelS$pred <- ols.pred
modelS$loss <- ols.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.05
modelS$method <- "ordinary"
modelS$subsample <- gSubsample

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 7, minsplits=10, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 7, minsplits=10, cp=0.001)
modelB$method <- "boulevard"
modelB$inflate <- 1

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- lm(c.formula(target, predictSet),
                data = simData$train)
    tmp <- c(tmp, 
             rLmFit = l2(predict(lmFit, newdata = simData$test), simData$yTest))
    
    lmFitSat <- lm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                   data = simData$train)
    tmp <- c(tmp, 
             rLmFitSat = l2(predict(lmFitSat, newdata = simData$test), simData$yTest))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "gaussian",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp <- c(tmp, 
             rGbmFit = l2(predict(gbmFit, newdata = simData$test, modelS$ntree), simData$yTest))

    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp <- c(tmp,
             rSvcmFit = l2(lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit),
                           simData$yTest))

    gc()
    modelB$n = sum(!testFlag) 
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp, rBvcmFitL = l2(tmpPred, simData$yTest),
             rBvcmFitR = l2(tmpPred * bvcmFit$inflate,  simData$yTest))
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))

#### DATASET: ENERGYEFFICIENCY ####
set.seed(42)
id <- "energyefficiency"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- subset(data, select = -c(11, 12))
data <- data[complete.cases(data), ]

result <- c()
actionCntSet <- c("X7")
actionFctSet <- c("X6", "X8")
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("X1", "X2", "X3")
target <- "Y1"
for (key in union(actionCntSet, predictSet)) {
    if (is.factor(data[[key]])) {
        data[[key]] = as.numeric(levels(data[[key]]))[data[[key]]]
    }
}
data <- data[complete.cases(data), ]
n <- dim(data)[1]
tenFold <- sample(1:10, size=n, replace=TRUE)

gSubsample <- 0.5

modelS <- list()
modelS$diff <- ols.diff
modelS$init <- ols.init.beta
modelS$pred <- ols.pred
modelS$loss <- ols.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.05
modelS$method <- "ordinary"
modelS$subsample <- gSubsample

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 2, minsplits=10, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 2, minsplits=10, cp=0.000)
modelB$method <- "boulevard"
modelB$inflate <- 1

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- lm(c.formula(target, predictSet),
                data = simData$train)
    tmp <- c(tmp, 
             rLmFit = l2(predict(lmFit, newdata = simData$test), simData$yTest))
    
    lmFitSat <- lm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                   data = simData$train)
    tmp <- c(tmp, 
             rLmFitSat = l2(predict(lmFitSat, newdata = simData$test), simData$yTest))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "gaussian",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp <- c(tmp, 
             rGbmFit = l2(predict(gbmFit, newdata = simData$test, modelS$ntree), simData$yTest))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp <- c(tmp,
             rSvcmFit = l2(lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit),
                           simData$yTest))

    gc()
    modelB$n = sum(!testFlag) 
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp, rBvcmFitL = l2(tmpPred, simData$yTest),
             rBvcmFitR = l2(tmpPred * bvcmFit$inflate,  simData$yTest))
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))

#### DATASET: EGRIDSTAB ####

set.seed(42)
id <- "egridstab"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- data[complete.cases(data), ]

result <- c()
actionCntSet <- c("tau2", "tau3", "tau4")
actionFctSet <- c()
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("p2", "p3", "p4", "g2", "g3", "g4")
target <- "stab"
for (key in union(actionCntSet, predictSet)) {
    if (is.factor(data[[key]])) {
        data[[key]] = as.numeric(levels(data[[key]]))[data[[key]]]
    }
}
data <- data[complete.cases(data), ]
n <- dim(data)[1]
tenFold <- sample(1:10, size=n, replace=TRUE)

gSubsample <- 0.5

modelS <- list()
modelS$diff <- ols.diff
modelS$init <- ols.init.beta
modelS$pred <- ols.pred
modelS$loss <- ols.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.05
modelS$method <- "ordinary"
modelS$subsample <- gSubsample

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 4, minsplits=10, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 4, minsplits=10, cp=0.001)
modelB$method <- "boulevard"
modelB$inflate <- 1

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- lm(c.formula(target, predictSet),
                data = simData$train)
    tmp <- c(tmp, 
             rLmFit = l2(predict(lmFit, newdata = simData$test), simData$yTest))
    
    lmFitSat <- lm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                   data = simData$train)
    tmp <- c(tmp, 
             rLmFitSat = l2(predict(lmFitSat, newdata = simData$test), simData$yTest))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "gaussian",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp <- c(tmp, 
             rGbmFit = l2(predict(gbmFit, newdata = simData$test, modelS$ntree), simData$yTest))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp <- c(tmp,
             rSvcmFit = l2(lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit),
                           simData$yTest))

    gc()
    modelB$n = sum(!testFlag) 
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp, rBvcmFitL = l2(tmpPred, simData$yTest),
             rBvcmFitR = l2(tmpPred * bvcmFit$inflate,  simData$yTest))
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))

#### END ####
#############

library(rpart)
library(gbm)
source("lgd.R")
library(pROC)

decompress <- function(data, 
                       actionCntSet, actionFctSet, predictSet,
                       testFlag) {
    res <- list()
    res$train <- subset(data, !testFlag)
    res$test <- subset(data, testFlag)
    res$xTrain <- c()
    res$yTrain <- c()
    res$zTrain <- c()
    res$xTest <- c()
    res$yTest <- c()
    res$zTest <- c()
    
    for (col in actionCntSet) {
        res$zTrain <- cbind(res$zTrain, as.numeric(as.vector(data[[col]]))[!testFlag])
        res$zTest <- cbind(res$zTest, as.numeric(as.vector(data[[col]]))[testFlag])
    }
    for (col in actionFctSet) {
        res$zTrain <- cbind(res$zTrain, as.numeric(as.factor(as.vector(data[[col]])))[!testFlag])
        res$zTest <- cbind(res$zTest, as.numeric(as.factor(as.vector(data[[col]])))[testFlag])
    }
    for (col in predictSet) {
        res$xTrain <- cbind(res$xTrain, as.numeric(as.vector(data[[col]]))[!testFlag])
        res$xTest <- cbind(res$xTest, as.numeric(as.vector(data[[col]]))[testFlag])
    }
    res$yTrain <-  as.numeric(as.vector(data[[target]]))[!testFlag]
    res$yTest <-  as.numeric(as.vector(data[[target]]))[testFlag]
    return(res)
}

c.formula <- function(target, predictSet, actionCntSet = c(), actionFctSet = c()) {
    strPredictSet <- paste(predictSet, collapse="+")
    strActionCntSet <- paste(actionCntSet, collapse="+")
    if (strActionCntSet != "") {
        strActionCntSet <- paste(strActionCntSet, "+", sep="")
    }
    strActionFctSet = ""
    if (!is.null(actionFctSet)) {
        strActionFctSet <- paste(paste("factor(", actionFctSet, ")", sep=""), collapse="+")
        strActionFctSet <- paste(strActionFctSet, "+", sep="")
    } 
    return(as.formula(paste(target, "~", strActionCntSet, strActionFctSet, strPredictSet, sep="")))
}

ce <- function(b, a) {
    b[b>0.9999] <- 0.9999;
    b[b<0.0001] <- 0.0001;
    return(mean(-a * log(b) - (1-a) * log(1-b)) / (-log(0.5)))
}

cep_DEPRECATED <- function(b, a) {
    b[b>10] <- 10
    b[b<-10] <- -10
    b <- sigmoid(b)
    return(mean(-a * log(b) - (1-a) * log(1-b)) / (-log(0.5)))
}

cep <- function(b, a) {
    return(mean( a == (b > 0)))
}

cepl <- function(b, a) {
    return(mean( a == (b > 0.5)))
}

#### DATASET: MAGIC ####
set.seed(42)
id <- "magic04"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = FALSE, sep = ",")
data <- data[complete.cases(data), ]
names(data) <- c("fLength", "fWidth", "fSize", "fConc", "fConc1", "fAsym", "fM3Long", "fM3Trans", "fAlpha", "fDist", "class")
data$target <- as.numeric(data$class == "g")

result <- c()
actionCntSet <- c("fSize", "fConc", "fConc1")
actionFctSet <- c()
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("fLength", "fWidth", "fAsym", "fM3Long", "fM3Trans", "fAlpha", "fDist")
target <- "target"
gSubsample <- 1

n <- nrow(data)
tenFold <- sample(1:10, size=n, replace=TRUE)

modelS <- list()
modelS$diff <- lg.diff
modelS$init <- lg.init.beta
modelS$pred <- lg.pred
modelS$loss <- lg.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.002
modelS$method <- "ordinary"
modelS$subsample <- gSubsample
modelS$quantile_truncate <- 0.05

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 6, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 0.1
modelB$control <- rpart.control(maxdepth = 6, minsplits=100, cp=0.001)
modelB$method <- "boulevard"

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- glm(c.formula(target, predictSet),
                 family = binomial(link = "logit"),
                 data = simData$train)
    tmp_pred <- predict(lmFit, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFit = cep(tmp_pred, simData$yTest),
             aucLmFit = auc(simData$yTest, tmp_pred))
    
    lmFitSat <- glm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                    family = binomial(link = "logit"),
                    data = simData$train)
    
    tmp_pred <- predict(lmFitSat, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFitSat = cep(tmp_pred, simData$yTest),
             aucLmFitSat = auc(simData$yTest, tmp_pred))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "adaboost",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp_pred <- predict(gbmFit, newdata = simData$test, modelS$ntree, type="link")
    tmp <- c(tmp, 
             rGbmFit = cep(tmp_pred, simData$yTest),
             aucGbmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp_pred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit)
    tmp <- c(tmp,
             rSvcmFit = cep(tmp_pred, simData$yTest),
             aucSvcmFit = auc(simData$yTest, tmp_pred))

    gc()
    modelB$n = sum(!testFlag)
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp,
             rBvcmFitL = cep(tmpPred, simData$yTest),
             aucBvcmFitL = auc(simData$yTest, tmpPred),
             rBvcmFitR = cep(tmpPred * (1+modelB$lambda) / modelB$lambda,  simData$yTest),
             aucBvcmFitR =  auc(simData$yTest, tmpPred * (1+modelB$lambda) / modelB$lambda))
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))

#### DATASET: BANK ####
set.seed(42)
id <- "bank"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ";")
data <- data[complete.cases(data), ]
data$target <- as.numeric(data$y == "yes")
data$pdays <- log(data$pdays + 2)
data$previous <- log(data$previous + 1)

result <- c()
actionCntSet <- c()
actionFctSet <- c("job", "marital", "education", "poutcome", "housing", "loan")
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("age", "balance", "duration", "pdays", "previous")
target <- "target"
gSubsample <- 1

n <- nrow(data)
tenFold <- sample(1:10, size=n, replace=TRUE)

modelS <- list()
modelS$diff <- lg.diff
modelS$init <- lg.init.beta
modelS$pred <- lg.pred
modelS$loss <- lg.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.05
modelS$method <- "ordinary"
modelS$subsample <- gSubsample
modelS$quantile_cut <- 0.05

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 7, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 7, minsplits=100, cp=0.00)
modelB$method <- "boulevard"

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- glm(c.formula(target, predictSet),
                 family = binomial(link = "logit"),
                 data = simData$train)
    tmp_pred <- predict(lmFit, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFit = cep(tmp_pred, simData$yTest),
             aucLmFit = auc(simData$yTest, tmp_pred))
    
    lmFitSat <- glm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                    family = binomial(link = "logit"),
                    data = simData$train)
    
    tmp_pred <- predict(lmFitSat, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFitSat = cep(tmp_pred, simData$yTest),
             aucLmFitSat = auc(simData$yTest, tmp_pred))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "adaboost",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp_pred <- predict(gbmFit, newdata = simData$test, modelS$ntree, type="link")
    tmp <- c(tmp, 
             rGbmFit = cep(tmp_pred, simData$yTest),
             aucGbmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp_pred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit)
    tmp <- c(tmp,
             rSvcmFit = cep(tmp_pred, simData$yTest),
             aucSvcmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelB$n = sum(!testFlag)
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp,
             rBvcmFitL = cep(tmpPred, simData$yTest),
             aucBvcmFitL = auc(simData$yTest, tmpPred),
             rBvcmFitR = cep(tmpPred * (1+modelB$lambda) / modelB$lambda,  simData$yTest),
             aucBvcmFitR =  auc(simData$yTest, tmpPred * (1+modelB$lambda) / modelB$lambda))

    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}


save(result, file=paste("Accuracy/", id, ".RData", sep=""))


#### DATASET: OCCUPANCY ####
set.seed(42)
id <- "occupancy"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- data[complete.cases(data), ]
data$month <- strptime(data$date, format = "%Y-%m-%d %H:%M:%S")$mon
data$day <- strptime(data$date, format = "%Y-%m-%d %H:%M:%S")$mday
data$weekday <- strptime(data$date, format = "%Y-%m-%d %H:%M:%S")$wday
data$hour <- strptime(data$date, format = "%Y-%m-%d %H:%M:%S")$hour
data$min <- strptime(data$date, format = "%Y-%m-%d %H:%M:%S")$min
data$target <- as.numeric(data$Occupancy == "1")
data <- data[complete.cases(data), ]

result <- c()
actionCntSet <- c("hour", "min")
actionFctSet <- c("weekday")
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("Temperature", "Humidity", "Light", "CO2", "HumidityRatio")
target <- "target"
gSubsample <- 0.5

n <- nrow(data)
tenFold <- sample(1:10, size=n, replace=TRUE)

modelS <- list()
modelS$diff <- lg.diff
modelS$init <- lg.init.beta
modelS$pred <- lg.pred
modelS$loss <- lg.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.1
modelS$method <- "ordinary"
modelS$subsample <- gSubsample
modelS$quantile_cut <- 0.05

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 7, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 7, minsplits=100, cp=0.00)
modelB$method <- "boulevard"

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- glm(c.formula(target, predictSet),
                 family = binomial(link = "logit"),
                 data = simData$train)
    tmp_pred <- predict(lmFit, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFit = cep(tmp_pred, simData$yTest),
             aucLmFit = auc(simData$yTest, tmp_pred))
    
    lmFitSat <- glm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                    family = binomial(link = "logit"),
                    data = simData$train)
    
    tmp_pred <- predict(lmFitSat, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFitSat = cep(tmp_pred, simData$yTest),
             aucLmFitSat = auc(simData$yTest, tmp_pred))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "adaboost",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp_pred <- predict(gbmFit, newdata = simData$test, modelS$ntree, type="link")
    tmp <- c(tmp, 
             rGbmFit = cep(tmp_pred, simData$yTest),
             aucGbmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp_pred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit)
    tmp <- c(tmp,
             rSvcmFit = cep(tmp_pred, simData$yTest),
             aucSvcmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelB$n = sum(!testFlag)
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp,
             rBvcmFitL = cep(tmpPred, simData$yTest),
             aucBvcmFitL = auc(simData$yTest, tmpPred),
             rBvcmFitR = cep(tmpPred * (1+modelB$lambda) / modelB$lambda,  simData$yTest),
             aucBvcmFitR =  auc(simData$yTest, tmpPred * (1+modelB$lambda) / modelB$lambda))

    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))

#### DATASET: SPAMBASE ####
set.seed(42)
id <- "spambase"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = FALSE, sep = ",")
data$target <- as.numeric(data$V58 == "1")
data <- data[complete.cases(data), ]

result <- c()
actionCntSet <- c("V55", "V56", "V57")
actionFctSet <- c()
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- paste("V", 1:54, sep="")
target <- "target"
gSubsample <- 0.5

n <- nrow(data)
tenFold <- sample(1:10, size=n, replace=TRUE)

modelS <- list()
modelS$diff <- lg.diff
modelS$init <- lg.init.beta
modelS$pred <- lg.pred
modelS$loss <- lg.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.1
modelS$method <- "ordinary"
modelS$subsample <- gSubsample
modelS$quantile_cut <- 0.05

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 5, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 5, minsplits=100, cp=0.00)
modelB$method <- "boulevard"

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- glm(c.formula(target, predictSet),
                 family = binomial(link = "logit"),
                 data = simData$train)
    tmp_pred <- predict(lmFit, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFit = cep(tmp_pred, simData$yTest),
             aucLmFit = auc(simData$yTest, tmp_pred))
    
    lmFitSat <- glm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                    family = binomial(link = "logit"),
                    data = simData$train)
    
    tmp_pred <- predict(lmFitSat, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFitSat = cep(tmp_pred, simData$yTest),
             aucLmFitSat = auc(simData$yTest, tmp_pred))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "adaboost",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp_pred <- predict(gbmFit, newdata = simData$test, modelS$ntree, type="link")
    tmp <- c(tmp, 
             rGbmFit = cep(tmp_pred, simData$yTest),
             aucGbmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp_pred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit)
    tmp <- c(tmp,
             rSvcmFit = cep(tmp_pred, simData$yTest),
             aucSvcmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelB$n = sum(!testFlag)
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp,
             rBvcmFitL = cep(tmpPred, simData$yTest),
             aucBvcmFitL = auc(simData$yTest, tmpPred),
             rBvcmFitR = cep(tmpPred * (1+modelB$lambda) / modelB$lambda,  simData$yTest),
             aucBvcmFitR =  auc(simData$yTest, tmpPred * (1+modelB$lambda) / modelB$lambda))

    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))
#### DATASET: ADULT ####
set.seed(42)
id <- "adult"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = FALSE, sep = ",")
data$target <- as.numeric(data$V15 == " <=50K")
data <- data[complete.cases(data), ]

result <- c()
actionCntSet <- c("V1")
actionFctSet <- c("V2", "V8", "V9", "V10")
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("V11", "V12", "V13", "V5")
target <- "target"
gSubsample <- 0.5

n <- nrow(data)
tenFold <- sample(1:10, size=n, replace=TRUE)

modelS <- list()
modelS$diff <- lg.diff
modelS$init <- lg.init.beta
modelS$pred <- lg.pred
modelS$loss <- lg.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.1
modelS$method <- "ordinary"
modelS$subsample <- gSubsample
modelS$quantile_cut <- 0.05

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 6, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 6, minsplits=100, cp=0.00)
modelB$method <- "boulevard"

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- glm(c.formula(target, predictSet),
                 family = binomial(link = "logit"),
                 data = simData$train)
    tmp_pred <- predict(lmFit, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFit = cep(tmp_pred, simData$yTest),
             aucLmFit = auc(simData$yTest, tmp_pred))
    
    lmFitSat <- glm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                    family = binomial(link = "logit"),
                    data = simData$train)
    
    tmp_pred <- predict(lmFitSat, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFitSat = cep(tmp_pred, simData$yTest),
             aucLmFitSat = auc(simData$yTest, tmp_pred))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "adaboost",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp_pred <- predict(gbmFit, newdata = simData$test, modelS$ntree, type="link")
    tmp <- c(tmp, 
             rGbmFit = cep(tmp_pred, simData$yTest),
             aucGbmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp_pred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit)
    tmp <- c(tmp,
             rSvcmFit = cep(tmp_pred, simData$yTest),
             aucSvcmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelB$n = sum(!testFlag)
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp,
             rBvcmFitL = cep(tmpPred, simData$yTest),
             aucBvcmFitL = auc(simData$yTest, tmpPred),
             rBvcmFitR = cep(tmpPred * (1+modelB$lambda) / modelB$lambda,  simData$yTest),
             aucBvcmFitR =  auc(simData$yTest, tmpPred * (1+modelB$lambda) / modelB$lambda))

    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))

#### DATASET: EGIRDSTAB_CLS ####

set.seed(42)
id <- "egridstab_cls"
cat("Working on Dataset: ", id, "...\n")

data <- read.table(paste("Accuracy/", id, ".csv", sep=""), header = TRUE, sep = ",")
data <- data[complete.cases(data), ]
data$target <- as.numeric(data$stabf == "stable")

result <- c()
actionCntSet <- c("tau2", "tau3", "tau4")
actionFctSet <- c()
actionSet <- union(actionCntSet, actionFctSet)
predictSet <- c("p2", "p3", "p4", "g2", "g3", "g4")
target <- "target"
for (key in union(actionCntSet, predictSet)) {
    if (is.factor(data[[key]])) {
        data[[key]] = as.numeric(levels(data[[key]]))[data[[key]]]
    }
}
data <- data[complete.cases(data), ]
n <- dim(data)[1]
tenFold <- sample(1:10, size=n, replace=TRUE)

gSubsample <- 0.5

n <- nrow(data)
tenFold <- sample(1:10, size=n, replace=TRUE)

modelS <- list()
modelS$diff <- lg.diff
modelS$init <- lg.init.beta
modelS$pred <- lg.pred
modelS$loss <- lg.loss
modelS$dummy <- TRUE
modelS$xscale <- TRUE
modelS$ntree <- 100
modelS$lambda <- 0.1
modelS$method <- "ordinary"
modelS$subsample <- gSubsample
modelS$quantile_cut <- 0.05

modelS$p <- length(predictSet) + modelS$dummy
modelS$q <- length(actionSet)
modelS$control <- rpart.control(maxdepth = 4, minsplits=100, cp=0.001)
modelS$woods <- list()

modelB <- modelS
modelB$lambda <- 1
modelB$control <- rpart.control(maxdepth = 4, minsplits=100, cp=0.00)
modelB$method <- "boulevard"

for (i in 1:10) {
    gc()
    testFlag <- (tenFold==i)
    simData <- decompress(data, 
                          actionCntSet, actionFctSet, predictSet,
                          testFlag)
    
    #### Linear Model
    tmp <- c()
    lmFit <- glm(c.formula(target, predictSet),
                 family = binomial(link = "logit"),
                 data = simData$train)
    tmp_pred <- predict(lmFit, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFit = cep(tmp_pred, simData$yTest),
             aucLmFit = auc(simData$yTest, tmp_pred))
    
    lmFitSat <- glm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                    family = binomial(link = "logit"),
                    data = simData$train)
    
    tmp_pred <- predict(lmFitSat, newdata = simData$test, type="link")
    tmp <- c(tmp, 
             rLmFitSat = cep(tmp_pred, simData$yTest),
             aucLmFitSat = auc(simData$yTest, tmp_pred))
    
    gbmFit <- gbm(c.formula(target, predictSet, actionCntSet, actionFctSet),
                  data = simData$train, 
                  distribution = "adaboost",
                  interaction.depth = modelS$control$maxdepth,
                  bag.fraction = gSubsample,
                  n.trees = modelS$ntree)
    tmp_pred <- predict(gbmFit, newdata = simData$test, modelS$ntree, type="link")
    tmp <- c(tmp, 
             rGbmFit = cep(tmp_pred, simData$yTest),
             aucGbmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelS$n = sum(!testFlag)
    svcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model=modelS)
    tmp_pred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=svcmFit)
    tmp <- c(tmp,
             rSvcmFit = cep(tmp_pred, simData$yTest),
             aucSvcmFit = auc(simData$yTest, tmp_pred))
    
    gc()
    modelB$n = sum(!testFlag)
    bvcmFit <- lgd(x=simData$xTrain, y=simData$yTrain, z=simData$zTrain, model = modelB)
    tmpPred <- lgd.predict(x=simData$xTest, z=simData$zTest, model=bvcmFit)
    tmp <- c(tmp,
             rBvcmFitL = cep(tmpPred, simData$yTest),
             aucBvcmFitL = auc(simData$yTest, tmpPred),
             rBvcmFitR = cep(tmpPred * (1+modelB$lambda) / modelB$lambda,  simData$yTest),
             aucBvcmFitR =  auc(simData$yTest, tmpPred * (1+modelB$lambda) / modelB$lambda))
    
    result <- rbind(result, tmp)
    cat("SIMULATION ITERATION ", i, "\n", tmp, "\n")
}

save(result, file=paste("Accuracy/", id, ".RData", sep=""))



#### HARVEST ####
simNameP <- c("beijingpm",
              "bikehour",
              "starcraft",
              "onlinenews",
              "energyefficiency",
              "egridstab")

simNamesA <- c("magic04",
               "bank",
               "occupancy",
               "spambase",
               "adult",
               "egridstab_cls") 

for (id in simNameP) {
    load(paste("Accuracy/", id, ".RData", sep=""))
    result <- result[complete.cases(result), ]
    result <- result[, 1:4]
    cat(toupper(id), " & ")
    cat(paste(
            paste(signif(apply(result, 2, mean), 4),
                  "(",
                  signif(apply(result, 2, sd), 3),
                  ")",
                  sep=""),
            collapse=" & "), "\\\\ \n")
}

for (id in simNamesA) {
    load(paste("Accuracy/", id, ".RData", sep=""))
    result <- result[complete.cases(result), ]
    result <- 1- result[, c(1, 3, 5, 7)]
    cat(toupper(id), " & ")
    cat(paste(
        paste(signif(apply(result, 2, mean), 3),
              "(",
              signif(apply(result, 2, sd), 2),
              ")",
              sep=""),
        collapse=" & "), "\\\\ \n")
}

for (id in simNamesA) {
  load(paste("Accuracy/", id, ".RData", sep=""))
  result <- result[complete.cases(result), ]
  result <- result[, c(2, 4, 6, 8)]
  cat(toupper(id), " & ")
  cat(paste(
    paste(signif(apply(result, 2, mean), 3),
          "(",
          signif(apply(result, 2, sd), 2),
          ")",
          sep=""),
    collapse=" & "), "\\\\ \n")
}
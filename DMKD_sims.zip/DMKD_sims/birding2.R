# Start with erd
setwd("~/Box Sync/Local Gradient Boosting/Simulation")
source("lgd.R")
load("erd.RData")
summary(erd)
lm_res <- lm(SCORE~., data=erd)
summary(lm_res)

znames <- c("lat", "lon", "YEAR")
xnames <- c("ELEV", 
            "Shallow_Ocean_ED", 
            "CoastShore_lines_ED",
            "Shallow_Inland_ED",
            "Moderate_Ocean_ED",
            "Deep_Ocean_ED",
            "Evergreen_needle_ED",
            "Grasslands_ED",
            "Croplands_ED",
            "Urban_Built_ED",
            "Barren_ED",
            "Evergreen_broad_ED",
            "Deciduous_needle_ED",
            "Deciduous_broad_ED",
            "Mixed_forest_ED",
            "Closed_shrubland_ED",
            "Open_shrubland_ED",
            "Woody_savannas_ED",
            "Savannas_ED")
ynames <- c(93:96)

y <- as.numeric(apply(erd, 1, function(x) sum(x[ynames])) > 0)

x <- c()
for (w_name in xnames) {
    x <- cbind(x, as.numeric(erd[, w_name]))
}
z <- c()
for (w_name in znames) {
    z <- cbind(z, as.numeric(erd[, w_name]))
}

model <- list()
model$dummy <- TRUE
model$xscale <- TRUE
model$n <- nrow(x)
model$p <- ncol(x) + model$dummy
model$q <- ncol(z)
model$diff <- lg.diff
model$init <- lg.init.beta
model$pred <- lg.pred
model$loss <- lg.loss
model$lambda <- 0.1
model$ntree <- 80
model$subsample <- 0.8
model$control <- rpart.control(maxdepth = 3, cp = 0.00)
model$method <- "plinear"
model$savetrees <- FALSE
model$woods <- list()

res <- lgd(y=y, x=x, z=z, model=model)
# save(res, file = "pl_res.RData")
# load("pl_res.RData")


ss <- ss[res$beta[ss, 1] < quantile(res$beta[ss, 1], 0.99) & res$beta[ss, 1] > quantile(res$beta[ss, 1], 0.01)]

png(filename="orni_2013.png", width=300, height=240)
ss <- sample(168914, 40000)
ss <- ss[erd[ss,]$"YEAR" <= 2013]
dat <- data.frame(Longitude = z[ss, 2], 
                  Latitude = z[ss, 1],
                  Val = res$beta[ss, 1])
g <- ggplot(dat, aes(Longitude, Latitude)) + 
    geom_point(aes(color = Val), cex=0.2) + 
    scale_color_distiller(palette="RdBu", direction=1, limits=c(-1, 1)) + 
    ggtitle("Intercept (before 2013)")
print(g)
dev.off()

png(filename="orni_2014.png", width=300, height=240)
ss <- sample(168914, 40000)
ss <- ss[erd[ss,]$"YEAR" == 2014]
dat <- data.frame(Longitude = z[ss, 2], 
                  Latitude = z[ss, 1],
                  Val = res$beta[ss, 1])
g <- ggplot(dat, aes(Longitude, Latitude)) + 
    geom_point(aes(color = Val), cex=0.2) + 
    scale_color_distiller(palette="RdBu", direction=1, limits=c(-1, 1)) + 
    ggtitle("Intercept (2014)")
print(g)
dev.off()

png(filename="orni_2015.png", width=300, height=240)
ss <- sample(168914, 40000)
ss <- ss[erd[ss,]$"YEAR" == 2015]
dat <- data.frame(Longitude = z[ss, 2], 
                  Latitude = z[ss, 1],
                  Val = res$beta[ss, 1])
g <- ggplot(dat, aes(Longitude, Latitude)) + 
    geom_point(aes(color = Val), cex=0.2) + 
    scale_color_distiller(palette="RdBu", direction=1, limits=c(-1, 1)) + 
    ggtitle("Intercept (2015)")
print(g)
dev.off()

png(filename="orni_2016.png", width=300, height=240)
ss <- sample(168914, 40000)
ss <- ss[erd[ss,]$"YEAR" == 2016]
dat <- data.frame(Longitude = z[ss, 2], 
                  Latitude = z[ss, 1],
                  Val = res$beta[ss, 1])
g <- ggplot(dat, aes(Longitude, Latitude)) + 
    geom_point(aes(color = Val), cex=0.2) + 
    scale_color_distiller(palette="RdBu", direction=1, limits=c(-1, 1)) + 
    ggtitle("Intercept (2016)")
print(g)
dev.off()

plot_ly(x=z[ss, 2], y=z[ss, 1], 
        color=res$beta[ss, 1], 
        type="scatter", mode="markers", colors=c("red", "lightgrey", "blue"),
        marker = list(size = 3.5)) %>%
    layout(title = "Score Intercept",
           xaxis = list(title="Longtitude"),
           yaxis = list(title="Latitude"))

plot_ly(x=z[ss, 2], y=z[ss, 3], 
        color=res$beta[ss, 1], 
        type="scatter", mode="markers", colors=c("red", "lightgrey", "blue"),
        marker = list(size = 3.5)) %>%
    layout(title = "Score Intercept",
           xaxis = list(title="Longtitude"),
           yaxis = list(title="Elevation"))

plot_ly(x=z[ss, 1], y=z[ss, 3], 
        color=res$beta[ss, 1], 
        type="scatter", mode="markers", colors=c("red", "lightgrey", "blue"),
        marker = list(size = 3.5)) %>%
    layout(title = "Score Intercept",
           xaxis = list(title="Latitude"),
           yaxis = list(title="Elevation"))

x <- read.csv("BeijingHousing/new.csv",sep=',',stringsAsFactors=FALSE, fileEncoding="latin1")


# if (!file.exists("new.Rda")) {
#   x <- read.csv("new.csv", sep = ",")
#   save(x, file = "new.Rda")
# } else {
#   load("new.Rda")
# }

x$livingRoom <- as.integer(x$livingRoom)
x$bathRoom <- as.integer(x$bathRoom)

source("mboost.R")
m <- gamboost(price ~ bbs(Lng, Lat, df = 6) +
                bbs(Lng, Lat, df = 6, by = bathRoom, center = TRUE) +
                bbs(Lng, Lat, df = 6, by = livingRoom, center = TRUE) +
                bbs(Lng, Lat, df = 6, by = elevator, center = TRUE),
              data = x)
### cvrisk(m) for early stopping

### visualise
nd <- expand.grid(Lng = seq(from = min(x$Lng), to = max(x$Lng), length = 50),
                  Lat = seq(from = min(x$Lat), to = max(x$Lat), length = 50))
nd$bathRoom <- nd$livingRoom <- nd$elevator <- 1L

int <- predict(m, newdata = nd, which = 1)
nd$int <- attr(int, "offset") + c(int)
nd$bath <- c(predict(m, newdata = nd, which = 2))
nd$living <- c(predict(m, newdata = nd, which = 3))
nd$elev <- c(predict(m, newdata = nd, which = 4))

library("lattice")
levelplot(int ~ Lng + Lat, data = nd)
levelplot(bath ~ Lng + Lat, data = nd)
levelplot(living ~ Lng + Lat, data = nd)
levelplot(elev ~ Lng + Lat, data = nd)
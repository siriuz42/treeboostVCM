# Start with erd
setwd("~/Box Sync/Local Gradient Boosting/Simulation")
source("lgd.R")
load("erd.RData")
summary(erd)
lm_res <- lm(SCORE~., data=erd)
summary(lm_res)

y <- erd$SCORE

znames <- c("lat", "lon")
xnames <- c("ELEV", 
            "Shallow_Ocean_ED", 
            "CoastShore_lines_ED",
            "Shallow_Inland_ED",
            "Moderate_Ocean_ED",
            "Deep_Ocean_ED",
            "Evergreen_needle_ED",
            "Grasslands_ED",
            "Croplands_ED",
            "Urban_Built_ED",
            "Barren_ED",
            "Evergreen_broad_ED",
            "Deciduous_needle_ED",
            "Deciduous_broad_ED",
            "Mixed_forest_ED",
            "Closed_shrubland_ED",
            "Open_shrubland_ED",
            "Woody_savannas_ED",
            "Savannas_ED")
x <- c()
for (w_name in xnames) {
    x <- cbind(x, as.numeric(erd[, w_name]))
}
z <- c()
for (w_name in znames) {
    z <- cbind(z, as.numeric(erd[, w_name]))
}

model <- list()
model$dummy <- TRUE
model$xscale <- TRUE
model$n <- nrow(x)
model$p <- ncol(x) + model$dummy
model$q <- ncol(z)
model$diff <- ols.diff
model$init <- ols.init.beta
model$pred <- ols.pred
model$loss <- ols.loss
model$lambda <- 0.05
model$ntree <- 75
model$subsample <- sample(model$n, min(model$n, 2000))
model$control <- rpart.control(maxdepth = 3, cp = 0.0001)
model$method <- "plinear"
model$savetrees <- FALSE
model$woods <- list()

res <- lgd(y=y, x=x, z=z, model=model)
save(res, file = "pl_res.RData")
load("pl_res.RData")

ss <- sample(168914, 10000)

png(filename="orni.png", width=300, height=240)
ss <- sample(168914, 10000)
ss <- ss[res$beta[ss, 1] < quantile(res$beta[ss, 1], 0.98) & res$beta[ss, 1] > quantile(res$beta[ss, 1], 0.02)]
dat <- data.frame(Longitude = z[ss, 2], 
                  Latitude = z[ss, 1],
                  Val = res$beta[ss, 1])
g <- ggplot(dat, aes(Longitude, Latitude)) + 
    geom_point(aes(color = Val), cex=0.2) + 
    scale_color_distiller(palette="RdBu", direction=1) + 
    ggtitle("Intercept")
print(g)
dev.off()

plot_ly(x=z[ss, 2], y=z[ss, 1], 
        color=res$beta[ss, 1], 
        type="scatter", mode="markers", colors=c("red", "lightgrey", "blue"),
        marker = list(size = 3.5)) %>%
    layout(title = "Score Intercept",
           xaxis = list(title="Longtitude"),
           yaxis = list(title="Latitude"))

plot_ly(x=z[ss, 2], y=z[ss, 3], 
        color=res$beta[ss, 1], 
        type="scatter", mode="markers", colors=c("red", "lightgrey", "blue"),
        marker = list(size = 3.5)) %>%
    layout(title = "Score Intercept",
           xaxis = list(title="Longtitude"),
           yaxis = list(title="Elevation"))

plot_ly(x=z[ss, 1], y=z[ss, 3], 
        color=res$beta[ss, 1], 
        type="scatter", mode="markers", colors=c("red", "lightgrey", "blue"),
        marker = list(size = 3.5)) %>%
    layout(title = "Score Intercept",
           xaxis = list(title="Latitude"),
           yaxis = list(title="Elevation"))
